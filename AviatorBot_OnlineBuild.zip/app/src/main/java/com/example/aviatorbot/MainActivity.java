package com.example.aviatorbot;
import android.app.*; import android.os.*; import android.widget.*; import java.util.*;

public class MainActivity extends Activity {
 EditText input; TextView signal, stats, history; ArrayList<Double> h=new ArrayList<>(); int wins=0, losses=0;
 public void onCreate(Bundle b){super.onCreate(b); setContentView(R.layout.activity_main);
  input=findViewById(R.id.multiplier); signal=findViewById(R.id.signal); stats=findViewById(R.id.stats); history=findViewById(R.id.history);
  findViewById(R.id.add).setOnClickListener(v->addRound());
 }
 void addRound(){
  try{
   double x=Double.parseDouble(input.getText().toString()); if(x<1) throw new Exception();
   h.add(x); input.setText("");
   // Test rule: signal is based only on the last 5 recorded results.
   if(h.size()>=2){
    double avg=0; int n=Math.min(5,h.size()); for(int i=h.size()-n;i<h.size();i++) avg+=h.get(i); avg/=n;
    signal.setText("Sinal de teste: "+(avg>=1.50?"ENTRAR":"NÃO ENTRAR")+"\nMédia recente: "+String.format("%.2f",avg)+"x");
   }
   StringBuilder s=new StringBuilder("Histórico:\n"); for(int i=h.size()-1;i>=0;i--) s.append(String.format(Locale.US,"%.2fx",h.get(i))).append(i==0?"":"  •  "); history.setText(s);
   // Accuracy is not claimed here because no independent prediction/cashout target was defined.
   stats.setText("Rodadas registadas: "+h.size()+"\nAcertos: "+wins+" | Erros: "+losses+" | Taxa: —");
  }catch(Exception e){ Toast.makeText(this,"Coloca um multiplicador válido, ex.: 1.72",Toast.LENGTH_SHORT).show(); }
 }
}
